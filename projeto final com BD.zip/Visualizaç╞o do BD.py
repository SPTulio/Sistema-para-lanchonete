import sqlite3


def listar_pedidos():
    global conn
    try:
        conn = sqlite3.connect('restaurante.db')
        cursor = conn.cursor()


        cursor.execute("SELECT * FROM pedidos")

        pedidos = cursor.fetchall()
        for pedido in pedidos:
            print(pedido)

    except sqlite3.Error as e:
        print(f"Erro ao acessar o banco de dados: {e}")

    finally:

        if conn:
            conn.close()


listar_pedidos()

input("\nPressione qualquer tecla para sair...")
