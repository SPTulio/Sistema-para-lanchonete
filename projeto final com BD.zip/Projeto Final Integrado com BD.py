import datetime
import random
import sqlite3

conn = sqlite3.connect('restaurante.db')
cursor = conn.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS pedidos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        numero_pedido TEXT,
        data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TEXT
    )
''')

cursor.execute('''
    CREATE TABLE IF NOT EXISTS funcionarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        senha TEXT
    )
''')

conn.commit()

cardapio = {
    "001": "Misto Quente",
    "002": "X-Burger",
    "003": "X-Salada",
    "004": "X-Batata",
    "005": "X-Egg",
    "006": "X-Dog",
    "007": "X-Frango",
    "008": "X-Italiano",
    "009": "X-Calabresa",
    "010": "X-Coração",
    "011": "X-Bacon",
    "012": "X-Tudo",
    "013": "Batata Frita"
}

ingredientes = {
    "001": ["pao", "queijo", "presunto"],
    "002": ["pao", "hamburguer", "queijo"],
    "003": ["pao", "hamburguer", "queijo", "alface", "tomate"],
    "004": ["pao", "batata palha"],
    "005": ["pao", "hamburguer", "queijo", "ovo"],
    "006": ["pao", "salsicha"],
    "007": ["pao", "frango desfiado", "queijo"],
    "008": ["pao", "salame"],
    "009": ["pao", "calabresa"],
    "010": ["pao", "coracao"],
    "011": ["pao", "bacon", "queijo"],
    "012": ["pao", "hamburguer", "queijo", "ovo", "bacon", "alface", "tomate"],
    "013": ["batata palha"]
}

precos = {
    "001": 5.00,
    "002": 6.00,
    "003": 7.00,
    "004": 9.00,
    "005": 9.00,
    "006": 10.00,
    "007": 10.00,
    "008": 10.00,
    "009": 10.00,
    "010": 10.00,
    "011": 10.00,
    "012": 15.00,
    "013": 7.00
}

estoque = {
    "pao": 50,
    "hamburguer": 30,
    "queijo": 20,
    "maionese": 15,
    "alface": 30,
    "tomate": 25,
    "milho": 20,
    "batata palha": 25,
    "ovo": 20,
    "salsicha": 15,
    "frango desfiado": 20,
    "salame": 15,
    "calabresa": 20,
    "coracao": 15,
    "bacon": 20,
    "presunto": 15
}

funcionarios = {"funcionario1", "funcionario2", "teste"}

login_funcionarios = {
    "funcionario1": "1234",
    "funcionario2": "5678",
    "teste": "1234"
}

candidatos = [
    {"nome": "Candidato 1", "area": "Cozinha"},
    {"nome": "Candidato 2", "area": "Atendimento"}
]

aprovados = []

protocolos_gerados = []

pontos = {
    "funcionario1": [],
    "funcionario2": [],
    "teste": []
}

justificativas = []


def saudacao():
    hora = datetime.datetime.now().hour
    if 6 <= hora < 12:
        print('Bom dia!')
    elif 12 <= hora < 18:
        print('Boa tarde!')
    else:
        print('Boa noite!')


def menu_principal():
    while True:
        try:
            saudacao()
            print('\nO que você deseja fazer?\n')
            print('1- Entrar como cliente')
            print('2- Entrar como funcionário')
            print('3- Entrar como proprietário')
            print('4- Entrar como candidato a funcionário')
            print('5- Sair')
            resp = int(input('Escolha uma opção: '))
            if resp == 1:
                menu_cliente()
            elif resp == 2:
                login_funcionario()
            elif resp == 3:
                login_dono()
            elif resp == 4:
                adicionar_candidato()
            elif resp == 5:
                print('Saindo do sistema...')
                break
            else:
                print('Opção inválida. Escolha novamente.')
        except ValueError:
            print('Digite apenas números.')


def menu_cliente():
    saudacao()
    print('\nN° do pedido | Nome do Pedido                          | Preço')
    for chave, valor in cardapio.items():
        preco = precos[chave]
        print(f"{chave:<13}| {valor:<42}| R${preco:.2f}")

    while True:
        try:
            pedido_input = input('\nDigite o número do pedido que você deseja (ou 0 para sair): ')
            if pedido_input == '0':
                break

            pedido = pedido_input.zfill(3)

            if pedido in cardapio:
                processar_pedido_cliente(pedido)
            else:
                print('Número de pedido inválido. Tente novamente.')

        except ValueError:
            print('Digite apenas números.')


def processar_pedido_cliente(numero_pedido):
    try:
        if verificar_estoque_pedido(numero_pedido):
            print(f"Pedido {numero_pedido} pode ser atendido. Preparando...")
            atualizar_estoque_pedido(numero_pedido)
            inserir_pedido_banco(numero_pedido)
            print(f"Pedido {numero_pedido} atendido com sucesso.")
        else:
            print(f"Não há estoque suficiente para atender o pedido {numero_pedido}.")
    except KeyError:
        print("Pedido inválido.")


def verificar_estoque_pedido(pedido):
    try:
        for item in ingredientes[pedido]:
            if estoque[item] == 0:
                return False
        return True
    except KeyError:
        print("Pedido inválido.")
        return False


def atualizar_estoque_pedido(pedido):
    for item in ingredientes[pedido]:
        estoque[item] -= 1


def inserir_pedido_banco(numero_pedido):
    cursor.execute('''
        INSERT INTO pedidos (numero_pedido, status)
        VALUES (?, ?)
    ''', (numero_pedido, 'Em preparo'))
    conn.commit()


def verificar_login(login, senha):
    if login in login_funcionarios and login_funcionarios[login] == senha:
        return True
    else:
        return False


def login_funcionario():
    tentativas = 3
    while tentativas > 0:
        login = input('Digite seu login: ')
        senha = input('Digite sua senha: ')
        if verificar_login(login, senha):
            print('Login realizado com sucesso!')
            menu_funcionario(login)
            break
        else:
            print('Login ou senha incorretos. Tente novamente.')
            tentativas -= 1
            if tentativas == 0:
                print('Número de tentativas excedido. Você foi bloqueado.')
                break


def menu_funcionario(funcionario):
    while True:
        try:
            print(f'\nBem-vindo, {funcionario}!\n')
            print('1- Ver estoque')
            print('2- Bater ponto')
            print('3- Justificar atestado')
            print('4- Sair')
            resp = int(input('Escolha uma opção: '))
            if resp == 1:
                print(estoque)
            elif resp == 2:
                bater_ponto(funcionario)
            elif resp == 3:
                justificar_atestado(funcionario)
            elif resp == 4:
                break
            else:
                print('Opção inválida. Escolha novamente.')
        except ValueError:
            print('Digite apenas números.')


def bater_ponto(funcionario):
    agora = datetime.datetime.now()
    registro = {"data": agora.strftime("%Y-%m-%d"), "hora": agora.strftime("%H:%M:%S")}
    pontos[funcionario].append(registro)
    print(f'Ponto registrado para {funcionario} às {registro["hora"]} do dia {registro["data"]}.')


def justificar_atestado(funcionario):
    mensagem = input('Digite a justificativa do atestado: ')
    justificativas.append({"funcionario": funcionario, "mensagem": mensagem})
    print('Justificativa registrada com sucesso.')


def login_dono():
    login = 'dono'
    senha = '1234'
    tentativas = 3
    while tentativas > 0:
        inplogin = input('Digite seu login: ')
        inpsenha = input('Digite sua senha: ')
        if inplogin == login and inpsenha == senha:
            print('Login realizado com sucesso!')
            menu_dono()
            break
        else:
            print('Login ou senha incorretos. Tente novamente.')
            tentativas -= 1
            if tentativas == 0:
                print('Número de tentativas excedido. Você foi bloqueado.')
                break


def menu_dono():
    while True:
        try:
            print('\nO que você deseja fazer?\n')
            print('1- Checar presença dos funcionários')
            print('2- Aprovar candidato a funcionário')
            print('3- Sair')
            resp = int(input('Escolha uma opção: '))
            if resp == 1:
                checar_presenca()
            elif resp == 2:
                aprovar_candidato()
            elif resp == 3:
                print('Saindo do sistema...')
                break
            else:
                print('Opção inválida. Escolha novamente.')
        except ValueError:
            print('Digite apenas números.')


def checar_presenca():
    for funcionario, registros in pontos.items():
        print(f'\nPontos registrados para {funcionario}:')
        for registro in registros:
            print(f'Data: {registro["data"]} | Hora: {registro["hora"]}')
    input('\nPressione ENTER para voltar ao menu.')


def aprovar_candidato():
    print('\nLista de candidatos:\n')
    for idx, candidato in enumerate(candidatos, start=1):
        print(f'{idx}. Nome: {candidato["nome"]} | Área de Interesse: {candidato["area"]}')

    while True:
        try:
            resp = int(input('\nQual candidato você deseja aprovar? (Digite o número ou 0 para sair): '))
            if 1 <= resp <= len(candidatos):
                candidato_aprovado = candidatos.pop(resp - 1)
                aprovados.append(candidato_aprovado)
                protocolo = random.randint(1000, 9999)
                protocolos_gerados.append(protocolo)
                print(f'\nCandidato {candidato_aprovado["nome"]} aprovado com sucesso.')
                print(f'Protocolo de contratação: {protocolo}')
                break
            elif resp == 0:
                break
            else:
                print('Opção inválida. Escolha novamente.')
        except ValueError:
            print('Digite apenas números.')


def adicionar_candidato():
    nome = input('Digite o nome do candidato: ')
    area = input('Digite a área de interesse do candidato: ')
    candidatos.append({"nome": nome, "area": area})
    print(f'Candidato {nome} adicionado com sucesso.')


def fechar_conexao():
    conn.close()
    print('Conexão com o banco de dados fechada.')


if __name__ == "__main__":
    try:
        menu_principal()
    finally:
        fechar_conexao()
